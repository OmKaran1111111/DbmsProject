<?php
// db_connect.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = '127.0.0.1';
$db   = 'jiffypay_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // We try to connect to jiffypay_db. If it fails due to unknown database, we create it.
    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (PDOException $e) {
        if ($e->getCode() == 1049) { // 1049 is Unknown database
            $pdo_temp = new PDO("mysql:host=$host;charset=$charset", $user, $pass, $options);
            $pdo_temp->exec("CREATE DATABASE IF NOT EXISTS `$db`");
            $pdo = new PDO($dsn, $user, $pass, $options);
            
            // Optionally, we could run the database.sql here, but typically it's run manually.
        } else {
            throw $e;
        }
    }
} catch (\PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

/**
 * Utility function to handle ACID transactions for financial movements
 */
function run_transaction($pdo, callable $callback) {
    try {
        $pdo->beginTransaction();
        $result = $callback($pdo);
        $pdo->commit();
        return ['success' => true, 'data' => $result];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
?>
