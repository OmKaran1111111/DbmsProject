
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

DROP TABLE IF EXISTS fraud_logs;
DROP TABLE IF EXISTS fraud_rules;
DROP TABLE IF EXISTS disputes;
DROP TABLE IF EXISTS virtual_cards;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS wallets;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS tenants;

CREATE TABLE tenants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    domain VARCHAR(100) UNIQUE NOT NULL,
    status ENUM('active', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tenant_id INT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'compliance', 'admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    wallet_number VARCHAR(20) UNIQUE NOT NULL,
    balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    currency VARCHAR(3) DEFAULT 'USD',
    status ENUM('active', 'frozen', 'closed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Transactions
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference_code VARCHAR(30) UNIQUE NOT NULL,
    sender_wallet_id INT,
    receiver_wallet_id INT,
    amount DECIMAL(15,2) NOT NULL,
    transaction_type ENUM('transfer', 'bill_pay', 'top_up') NOT NULL,
    status ENUM('pending', 'completed', 'failed', 'escrow') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_wallet_id) REFERENCES wallets(id) ON DELETE SET NULL,
    FOREIGN KEY (receiver_wallet_id) REFERENCES wallets(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 5. Virtual Cards
CREATE TABLE virtual_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    wallet_id INT NOT NULL,
    card_number VARCHAR(16) UNIQUE NOT NULL,
    expiry_date VARCHAR(5) NOT NULL,
    cvv VARCHAR(4) NOT NULL,
    card_type ENUM('burner', 'permanent') NOT NULL,
    spending_limit DECIMAL(15,2) DEFAULT NULL,
    status ENUM('active', 'inactive', 'used') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE
) ENGINE=InnoDB;


CREATE TABLE disputes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT NOT NULL,
    initiator_id INT NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('open', 'under_review', 'resolved_refunded', 'resolved_rejected') DEFAULT 'open',
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE,
    FOREIGN KEY (initiator_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE fraud_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    condition_type ENUM('max_amount_single', 'velocity_daily') NOT NULL,
    threshold_value DECIMAL(15,2) NOT NULL,
    action_to_take ENUM('flag', 'block') DEFAULT 'flag',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE fraud_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id INT NULL,
    user_id INT NULL,
    rule_id INT NOT NULL,
    description TEXT,
    logged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending_review', 'cleared', 'confirmed_fraud') DEFAULT 'pending_review',
    FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (rule_id) REFERENCES fraud_rules(id) ON DELETE CASCADE
) ENGINE=InnoDB;


INSERT INTO fraud_rules (rule_name, condition_type, threshold_value, action_to_take) VALUES
('High Single Transaction', 'max_amount_single', 10000.00, 'flag'),
('Extreme Single Transaction', 'max_amount_single', 50000.00, 'block');

INSERT INTO tenants (name, domain) VALUES ('JiffyPay HQ', 'jiffypay.com');

INSERT INTO users (tenant_id, full_name, email, password_hash, role) VALUES 
(1, 'Super Admin', 'admin@jiffypay.com', '$2y$10$ak8joc5j4c8dNlKl5zYtIOs6MCI1EGheYL46bMPG8duwBCYY9Rkde', 'admin'),
(1, 'Compliance Agent', 'compliance@jiffypay.com', '$2y$10$ak8joc5j4c8dNlKl5zYtIOs6MCI1EGheYL46bMPG8duwBCYY9Rkde', 'compliance'),
(1, 'John Doe', 'john@example.com', '$2y$10$ak8joc5j4c8dNlKl5zYtIOs6MCI1EGheYL46bMPG8duwBCYY9Rkde', 'customer'),
(1, 'Om', 'om@example.com', '$2y$10$ak8joc5j4c8dNlKl5zYtIOs6MCI1EGheYL46bMPG8duwBCYY9Rkde', 'customer'),
(1, 'Sarim', 'sarim@example.com', '$2y$10$ak8joc5j4c8dNlKl5zYtIOs6MCI1EGheYL46bMPG8duwBCYY9Rkde', 'customer'),
(1, 'Waqar', 'waqar@example.com', '$2y$10$ak8joc5j4c8dNlKl5zYtIOs6MCI1EGheYL46bMPG8duwBCYY9Rkde', 'customer');

INSERT INTO wallets (user_id, wallet_number, balance) VALUES 
(3, 'W-1000000001', 5000.00),
(4, 'W-1000000002', 1500.00),
(5, 'W-1000000003', 2500.00),
(6, 'W-1000000004', 3000.00);

DROP VIEW IF EXISTS view_user_statements;
CREATE VIEW view_user_statements AS
SELECT 
    t.id AS transaction_id,
    w.user_id,
    w.id AS wallet_id,
    t.created_at,
    t.transaction_type,
    t.reference_code,
    CASE 
        WHEN t.sender_wallet_id = w.id THEN -t.amount
        ELSE t.amount
    END as amount_change,
    t.status,
    SUM(
        CASE 
            WHEN t.sender_wallet_id = w.id THEN -t.amount
            ELSE t.amount
        END
    ) OVER (PARTITION BY w.id ORDER BY t.created_at ASC) as running_balance
FROM transactions t
JOIN wallets w ON t.sender_wallet_id = w.id OR t.receiver_wallet_id = w.id
WHERE t.status IN ('completed', 'escrow');

DROP VIEW IF EXISTS view_active_disputes;
CREATE VIEW view_active_disputes AS
SELECT 
    d.id AS dispute_id,
    d.transaction_id,
    t.reference_code,
    t.amount,
    u.full_name AS initiator_name,
    d.reason,
    d.status,
    d.created_at
FROM disputes d
JOIN transactions t ON d.transaction_id = t.id
JOIN users u ON d.initiator_id = u.id
WHERE d.status IN ('open', 'under_review');


DELIMITER //

DROP PROCEDURE IF EXISTS process_p2p_transfer //
CREATE PROCEDURE process_p2p_transfer(
    IN p_sender_wallet INT,
    IN p_receiver_wallet_num VARCHAR(50),
    IN p_amount DECIMAL(15,2),
    OUT p_ref VARCHAR(30),
    OUT p_status VARCHAR(20),
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_receiver_id INT;
    DECLARE v_sender_balance DECIMAL(15,2);
    DECLARE v_rule_id INT;
    DECLARE v_rule_threshold DECIMAL(15,2);
    DECLARE v_action VARCHAR(20);
    DECLARE v_tx_id INT;
    
    SET p_ref = CONCAT('TRX-', UPPER(SUBSTRING(MD5(RAND()), 1, 10)));
    
    SELECT id INTO v_receiver_id FROM wallets WHERE wallet_number = p_receiver_wallet_num FOR UPDATE;
    IF v_receiver_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Recipient wallet not found.';
    END IF;
    
    SELECT balance INTO v_sender_balance FROM wallets WHERE id = p_sender_wallet FOR UPDATE;
    IF v_sender_balance < p_amount THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance.';
    END IF;
    
    UPDATE wallets SET balance = balance - p_amount WHERE id = p_sender_wallet;
    
    SELECT id, threshold_value, action_to_take INTO v_rule_id, v_rule_threshold, v_action
    FROM fraud_rules 
    WHERE condition_type = 'max_amount_single' AND action_to_take = 'block'
    ORDER BY threshold_value ASC LIMIT 1;
    
    IF p_amount >= v_rule_threshold THEN
        INSERT INTO transactions (reference_code, sender_wallet_id, receiver_wallet_id, amount, transaction_type, status) 
        VALUES (p_ref, p_sender_wallet, v_receiver_id, p_amount, 'transfer', 'pending');
        
        SET v_tx_id = LAST_INSERT_ID();
        
        INSERT INTO fraud_logs (transaction_id, user_id, rule_id, description)
        VALUES (v_tx_id, (SELECT user_id FROM wallets WHERE id = p_sender_wallet), v_rule_id, CONCAT('Transaction held for high amount: $', p_amount));
        
        SET p_status = 'pending';
        SET p_message = 'Transaction flagged for fraud review. Funds held.';
    ELSE
        UPDATE wallets SET balance = balance + p_amount WHERE id = v_receiver_id;
        
        INSERT INTO transactions (reference_code, sender_wallet_id, receiver_wallet_id, amount, transaction_type, status) 
        VALUES (p_ref, p_sender_wallet, v_receiver_id, p_amount, 'transfer', 'completed');
        
        SET v_tx_id = LAST_INSERT_ID();
        
        SELECT id, threshold_value INTO v_rule_id, v_rule_threshold
        FROM fraud_rules 
        WHERE condition_type = 'max_amount_single' AND action_to_take = 'flag'
        ORDER BY threshold_value ASC LIMIT 1;
        
        IF p_amount >= v_rule_threshold THEN
            INSERT INTO fraud_logs (transaction_id, user_id, rule_id, description)
            VALUES (v_tx_id, (SELECT user_id FROM wallets WHERE id = p_sender_wallet), v_rule_id, CONCAT('Transaction flagged for high amount: $', p_amount));
        END IF;
        
        SET p_status = 'completed';
        SET p_message = 'Transfer successful.';
    END IF;
END //

DROP PROCEDURE IF EXISTS generate_burner_card //
CREATE PROCEDURE generate_burner_card(IN p_wallet_id INT, OUT p_card_number VARCHAR(16))
BEGIN
    DECLARE v_card_num VARCHAR(16);
    DECLARE v_cvv VARCHAR(4);
    DECLARE v_expiry VARCHAR(5);
    
    SET v_card_num = CONCAT('4', LPAD(FLOOR(RAND() * 999999999999999), 15, '0'));
    SET v_cvv = LPAD(FLOOR(RAND() * 999), 3, '0');
    SET v_expiry = CONCAT(LPAD(MONTH(CURRENT_DATE()), 2, '0'), '/', RIGHT(YEAR(CURRENT_DATE() + INTERVAL 1 YEAR), 2));
    
    INSERT INTO virtual_cards (wallet_id, card_number, expiry_date, cvv, card_type)
    VALUES (p_wallet_id, v_card_num, v_expiry, v_cvv, 'burner');
    
    SET p_card_number = v_card_num;
END //

DROP PROCEDURE IF EXISTS process_fraud_resolution //
CREATE PROCEDURE process_fraud_resolution(
    IN p_log_id INT, 
    IN p_resolution VARCHAR(20)
)
BEGIN
    DECLARE v_trans_id INT;
    DECLARE v_sender_wallet INT;
    DECLARE v_receiver_wallet INT;
    DECLARE v_amount DECIMAL(15,2);
    DECLARE v_trans_status VARCHAR(20);
    
    SELECT transaction_id INTO v_trans_id FROM fraud_logs WHERE id = p_log_id;
    SELECT sender_wallet_id, receiver_wallet_id, amount, status 
    INTO v_sender_wallet, v_receiver_wallet, v_amount, v_trans_status
    FROM transactions WHERE id = v_trans_id FOR UPDATE;
    
    IF v_trans_status = 'pending' THEN
        IF p_resolution = 'approve' THEN
            UPDATE wallets SET balance = balance + v_amount WHERE id = v_receiver_wallet;
            UPDATE transactions SET status = 'completed' WHERE id = v_trans_id;
            UPDATE fraud_logs SET status = 'cleared' WHERE id = p_log_id;
        ELSEIF p_resolution = 'backtrack' THEN
            UPDATE wallets SET balance = balance + v_amount WHERE id = v_sender_wallet;
            UPDATE transactions SET status = 'failed' WHERE id = v_trans_id;
            UPDATE fraud_logs SET status = 'confirmed_fraud' WHERE id = p_log_id;
        END IF;
    ELSEIF v_trans_status = 'completed' THEN
        IF p_resolution = 'revert' THEN
            UPDATE wallets SET balance = balance - v_amount WHERE id = v_receiver_wallet;
            UPDATE wallets SET balance = balance + v_amount WHERE id = v_sender_wallet;
            UPDATE transactions SET status = 'failed' WHERE id = v_trans_id;
            UPDATE fraud_logs SET status = 'confirmed_fraud' WHERE id = p_log_id;
        END IF;
    END IF;
END //

DROP PROCEDURE IF EXISTS process_dispute_resolution //
CREATE PROCEDURE process_dispute_resolution(
    IN p_dispute_id INT, 
    IN p_resolution VARCHAR(20),
    IN p_notes TEXT
)
BEGIN
    DECLARE v_trans_id INT;
    DECLARE v_sender_wallet INT;
    DECLARE v_receiver_wallet INT;
    DECLARE v_amount DECIMAL(15,2);
    DECLARE v_trans_status VARCHAR(20);
    DECLARE v_ref VARCHAR(30);
    
    SELECT transaction_id INTO v_trans_id FROM disputes WHERE id = p_dispute_id;
    SELECT sender_wallet_id, receiver_wallet_id, amount, status, reference_code 
    INTO v_sender_wallet, v_receiver_wallet, v_amount, v_trans_status, v_ref
    FROM transactions WHERE id = v_trans_id;
    
    IF v_trans_status = 'escrow' THEN
        IF p_resolution = 'refund' THEN
            UPDATE wallets SET balance = balance + v_amount WHERE id = v_sender_wallet;
            UPDATE transactions SET status = 'completed' WHERE id = v_trans_id;
            
            INSERT INTO transactions (reference_code, sender_wallet_id, receiver_wallet_id, amount, transaction_type, status, notes)
            VALUES (CONCAT('REF-', v_ref, '-', FLOOR(RAND() * 1000)), v_receiver_wallet, v_sender_wallet, v_amount, 'transfer', 'completed', 'Dispute Refund');
            
            UPDATE disputes SET status = 'resolved_refunded', resolution_notes = p_notes WHERE id = p_dispute_id;
        ELSEIF p_resolution = 'reject' THEN
            UPDATE wallets SET balance = balance + v_amount WHERE id = v_receiver_wallet;
            UPDATE transactions SET status = 'completed' WHERE id = v_trans_id;
            UPDATE disputes SET status = 'resolved_rejected', resolution_notes = p_notes WHERE id = p_dispute_id;
        END IF;
    END IF;
END //

DROP PROCEDURE IF EXISTS generate_global_revenue_report //
CREATE PROCEDURE generate_global_revenue_report()
BEGIN
    SELECT 
        DATE(created_at) as report_date,
        COUNT(id) as total_transactions,
        SUM(amount) as daily_volume,
        transaction_type,
        SUM(SUM(amount)) OVER (ORDER BY DATE(created_at)) as running_platform_volume,
        RANK() OVER (ORDER BY SUM(amount) DESC) as daily_volume_rank
    FROM transactions
    WHERE status = 'completed'
    GROUP BY DATE(created_at), transaction_type
    ORDER BY report_date DESC;
END //

DELIMITER ;

COMMIT;
