<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");

include __DIR__ . "/db.php";

$data = [];

/* ---------------- CUSTOMERS ---------------- */
$res = $conn->query("SELECT * FROM customers");
$data['customers'] = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];

/* ---------------- TRANSACTIONS ---------------- */
$res = $conn->query("SELECT * FROM transactions ORDER BY id DESC");
$data['transactions'] = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];

/* ---------------- CARDS ---------------- */
$res = $conn->query("SELECT * FROM cards");
$data['cards'] = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];

/* ---------------- DISPUTES ---------------- */
$res = $conn->query("SELECT * FROM disputes ORDER BY id DESC");
$data['disputes'] = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];

/* ---------------- METRICS ---------------- */
$customerCount = count($data['customers']);
$totalBalance = 0;

foreach ($data['customers'] as $c) {
    $totalBalance += (float)$c['balance'];
}

$totalVolume = 0;
foreach ($data['transactions'] as $t) {
    $totalVolume += (float)$t['amount'];
}

$data['metrics'] = [
    "customerCount" => $customerCount,
    "walletFloat" => $totalBalance,
    "totalVolume" => $totalVolume,
    "activeCards" => count($data['cards']),
    "openAlerts" => 0,
    "openDisputes" => count($data['disputes'])
];

/* ---------------- EXTRA FIELDS (for JS compatibility) ---------------- */
$data['fraudAlerts'] = [];
$data['officers'] = [];
$data['generatedAt'] = date("c");

/* ---------------- OUTPUT ---------------- */
echo json_encode($data);