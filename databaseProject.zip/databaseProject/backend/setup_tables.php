<?php
require_once __DIR__ . '/db.php';

$sqlFile = __DIR__ . '/../schema.sql';

if (!file_exists($sqlFile)) {
    die(json_encode(["message" => "Schema file not found"]));
}

$sql = file_get_contents($sqlFile);

if ($conn->multi_query($sql)) {
    do {
        if ($res = $conn->store_result()) {
            $res->free();
        }
    } while ($conn->more_results() && $conn->next_result());
    echo json_encode(["message" => "Tables created successfully!"]);
} else {
    echo json_encode(["message" => "Error creating tables: " . $conn->error]);
}

$conn->close();
?>
