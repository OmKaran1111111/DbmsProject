<?php
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$name = $data['fullName'];
$email = $data['email'];
$phone = $data['phone'];
$balance = $data['openingBalance'];

$wallet = "JP" . rand(100000, 999999);

$stmt = $conn->prepare("INSERT INTO customers(full_name,email,phone,wallet_number,balance) VALUES(?,?,?,?,?)");
$stmt->bind_param("ssssd", $name, $email, $phone, $wallet, $balance);
$stmt->execute();

echo json_encode(["message" => "Customer created"]);
?>