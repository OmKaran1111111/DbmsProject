<?php
$conn = new mysqli("localhost", "root", "", "project");

if ($conn->connect_error) {
    die(json_encode(["message" => "Database connection failed"]));
}

header("Content-Type: application/json");
?>