<?php
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$user = $data['userId'];
$label = $data['cardLabel'];
$type = $data['cardType'];
$limit = $data['spendingLimit'];

$number = "**** **** **** " . rand(1000,9999);

$conn->query("INSERT INTO cards(user_id,card_label,card_type,masked_number,spending_limit,status)
VALUES($user,'$label','$type','$number',$limit,'active')");

echo json_encode(["message"=>"Card issued"]);
?>