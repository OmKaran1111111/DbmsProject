<?php
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$tx = $data['transactionId'];
$user = $data['customerUserId'];
$reason = $data['reason'];

$conn->query("INSERT INTO disputes(transaction_id,customer_id,reason,status)
VALUES($tx,$user,'$reason','open')");

echo json_encode(["message"=>"Dispute created"]);
?>