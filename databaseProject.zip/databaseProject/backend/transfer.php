<?php
include "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$sender = $data['senderWalletId'];
$receiver = $data['receiverWalletId'];
$amount = $data['amount'];

$conn->query("UPDATE customers SET balance = balance - $amount WHERE id = $sender");
$conn->query("UPDATE customers SET balance = balance + $amount WHERE id = $receiver");

$ref = "TX" . rand(100000,999999);

$conn->query("INSERT INTO transactions(reference_code,sender_id,receiver_id,amount,status,transaction_type)
VALUES('$ref',$sender,$receiver,$amount,'completed','transfer')");

echo json_encode(["message"=>"Transfer successful"]);
?>