<?php
require 'db_connect.php';

try {
    // 1. Create a transfer
    $pdo->exec("INSERT INTO transactions (reference_code, sender_wallet_id, receiver_wallet_id, amount, transaction_type, status) VALUES ('TEST-TX-123', 1, 2, 50, 'transfer', 'completed')");
    $tx_id = $pdo->lastInsertId();

    // 2. Open dispute
    $stmt = $pdo->prepare("INSERT INTO disputes (transaction_id, initiator_id, reason) VALUES (?, 3, 'Test dispute')");
    $stmt->execute([$tx_id]);
    $dispute_id = $pdo->lastInsertId();

    $pdo->exec("UPDATE transactions SET status = 'escrow' WHERE id = $tx_id");

    // 3. Resolve dispute
    $stmt = $pdo->prepare("CALL process_dispute_resolution(?, 'refund', 'resolved')");
    $stmt->execute([$dispute_id]);
    echo 'Dispute resolved successfully. ';
} catch(Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
