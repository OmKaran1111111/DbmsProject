<?php
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Fetch Global Revenue Report via Stored Procedure
try {
    $stmt = $pdo->query("CALL generate_global_revenue_report()");
    $revenue_report = $stmt->fetchAll();
    $stmt->closeCursor(); // Free the connection for the next query
} catch (PDOException $e) {
    die("Error fetching revenue report: " . $e->getMessage());
}

// Fetch Tenants
try {
    $stmt = $pdo->query("SELECT * FROM tenants ORDER BY created_at DESC");
    $tenants = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error fetching tenants: " . $e->getMessage());
}

// Fetch Users stats
$stmt = $pdo->query("SELECT role, COUNT(id) as count FROM users GROUP BY role");
$users_stats = $stmt->fetchAll();

// Fetch All Transactions
$stmt = $pdo->query("SELECT t.*, s.wallet_number as sender, r.wallet_number as receiver 
                     FROM transactions t 
                     LEFT JOIN wallets s ON t.sender_wallet_id = s.id 
                     LEFT JOIN wallets r ON t.receiver_wallet_id = r.id 
                     ORDER BY t.created_at DESC LIMIT 50");
$all_transactions = $stmt->fetchAll();

// Fetch All Customers
$stmt = $pdo->query("SELECT u.*, w.wallet_number, w.balance FROM users u LEFT JOIN wallets w ON u.id = w.user_id WHERE u.role = 'customer' ORDER BY u.created_at DESC");
$all_customers = $stmt->fetchAll();

// Fetch All Complaints (Disputes)
$stmt = $pdo->query("SELECT d.*, t.reference_code, u.full_name as initiator_name FROM disputes d JOIN transactions t ON d.transaction_id = t.id JOIN users u ON d.initiator_id = u.id ORDER BY d.created_at DESC");
$all_disputes = $stmt->fetchAll();

// Fetch All Employees
$stmt = $pdo->query("SELECT * FROM users WHERE role IN ('compliance', 'admin') ORDER BY role, full_name");
$all_employees = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - JiffyPay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-glass py-3 mb-4">
  <div class="container">
    <a class="navbar-brand fs-4" href="#">JiffyPay <span class="fs-6 text-white fw-normal">| Admin Panel</span></a>
    <div class="d-flex align-items-center">
        <span class="text-main me-3">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></span>
        <a href="logout.php" class="btn btn-outline-custom btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
    
    <div class="row g-4 mb-4">
        <!-- Overview Stats -->
        <?php foreach($users_stats as $stat): ?>
            <div class="col-md-3">
                <div class="glass-card text-center">
                    <h6 class="text-muted-custom text-uppercase">Total <?= htmlspecialchars($stat['role']) ?>s</h6>
                    <h2 class="text-gradient fw-bold mb-0"><?= number_format($stat['count']) ?></h2>
                </div>
            </div>
        <?php endforeach; ?>
        <div class="col-md-3">
            <div class="glass-card text-center border-primary">
                <h6 class="text-muted-custom text-uppercase">Total Tenants</h6>
                <h2 class="text-white fw-bold mb-0"><?= count($tenants) ?></h2>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Revenue Report -->
        <div class="col-md-8">
            <div class="glass-card h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="mb-0">Global Revenue Analytics</h5>
                    <span class="badge bg-primary">Powered by Window Functions</span>
                </div>
                
                <div class="table-responsive">
                    <table class="table table-glass align-middle">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Tx Count</th>
                                <th class="text-end">Daily Volume</th>
                                <th class="text-end">Running Platform Vol.</th>
                                <th class="text-center">Volume Rank</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($revenue_report)): ?>
                                <tr><td colspan="6" class="text-center text-muted-custom">No data available.</td></tr>
                            <?php else: ?>
                                <?php foreach($revenue_report as $row): ?>
                                    <tr>
                                        <td><?= date('M j, Y', strtotime($row['report_date'])) ?></td>
                                        <td class="text-capitalize"><?= htmlspecialchars($row['transaction_type']) ?></td>
                                        <td><?= $row['total_transactions'] ?></td>
                                        <td class="text-end text-success fw-bold">$<?= number_format($row['daily_volume'], 2) ?></td>
                                        <td class="text-end fw-bold">$<?= number_format($row['running_platform_volume'], 2) ?></td>
                                        <td class="text-center">
                                            <?php if($row['daily_volume_rank'] == 1): ?>
                                                <span class="badge bg-warning text-dark">#1</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">#<?= $row['daily_volume_rank'] ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Tenant Management -->
        <div class="col-md-4">
            <div class="glass-card h-100">
                <h5 class="mb-4">SaaS Tenants</h5>
                
                <ul class="list-group list-group-flush" data-bs-theme="dark">
                    <?php foreach($tenants as $tenant): ?>
                        <li class="list-group-item bg-transparent border-secondary px-0">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <strong class="text-white"><?= htmlspecialchars($tenant['name']) ?></strong>
                                <span class="badge <?= $tenant['status'] == 'active' ? 'bg-success' : 'bg-danger' ?>"><?= ucfirst($tenant['status']) ?></span>
                            </div>
                            <div class="small text-muted-custom">
                                Domain: <?= htmlspecialchars($tenant['domain']) ?><br>
                                Joined: <?= date('M Y', strtotime($tenant['created_at'])) ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- Additional Data Sections -->
    <div class="row g-4 mt-2">
        <div class="col-12">
            <div class="glass-card">
                <ul class="nav nav-pills mb-3" id="admin-tabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active btn-outline-custom" id="tx-tab" data-bs-toggle="pill" data-bs-target="#tx" type="button" role="tab">All Transactions</button>
                    </li>
                    <li class="nav-item ms-2" role="presentation">
                        <button class="nav-link btn-outline-custom" id="customers-tab" data-bs-toggle="pill" data-bs-target="#customers" type="button" role="tab">All Customers</button>
                    </li>
                    <li class="nav-item ms-2" role="presentation">
                        <button class="nav-link btn-outline-custom" id="disputes-tab" data-bs-toggle="pill" data-bs-target="#disputes" type="button" role="tab">All Complaints</button>
                    </li>
                    <li class="nav-item ms-2" role="presentation">
                        <button class="nav-link btn-outline-custom" id="employees-tab" data-bs-toggle="pill" data-bs-target="#employees" type="button" role="tab">All Employees</button>
                    </li>
                </ul>

                <div class="tab-content" id="admin-tabs-content">
                    <!-- Transactions Tab -->
                    <div class="tab-pane fade show active" id="tx" role="tabpanel" tabindex="0">
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-glass align-middle">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Ref</th>
                                        <th>Type</th>
                                        <th>Sender Wallet</th>
                                        <th>Receiver Wallet</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($all_transactions as $tx): ?>
                                    <tr>
                                        <td><?= date('M j, Y H:i', strtotime($tx['created_at'])) ?></td>
                                        <td><?= htmlspecialchars($tx['reference_code']) ?></td>
                                        <td><span class="badge bg-dark"><?= htmlspecialchars($tx['transaction_type']) ?></span></td>
                                        <td><?= htmlspecialchars($tx['sender'] ?? 'N/A') ?></td>
                                        <td><?= htmlspecialchars($tx['receiver'] ?? 'N/A') ?></td>
                                        <td class="text-success fw-bold">$<?= number_format($tx['amount'], 2) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($tx['status']) ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Customers Tab -->
                    <div class="tab-pane fade" id="customers" role="tabpanel" tabindex="0">
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-glass align-middle">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Wallet Number</th>
                                        <th>Balance</th>
                                        <th>Joined</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($all_customers as $c): ?>
                                    <tr>
                                        <td><?= $c['id'] ?></td>
                                        <td><?= htmlspecialchars($c['full_name']) ?></td>
                                        <td><?= htmlspecialchars($c['email']) ?></td>
                                        <td><span class="badge bg-primary"><?= htmlspecialchars($c['wallet_number'] ?? 'N/A') ?></span></td>
                                        <td class="fw-bold">$<?= number_format($c['balance'] ?? 0, 2) ?></td>
                                        <td><?= date('M j, Y', strtotime($c['created_at'])) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Disputes Tab -->
                    <div class="tab-pane fade" id="disputes" role="tabpanel" tabindex="0">
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-glass align-middle">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Initiator</th>
                                        <th>Tx Ref</th>
                                        <th>Reason</th>
                                        <th>Status</th>
                                        <th>Resolution Notes</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($all_disputes as $d): ?>
                                    <tr>
                                        <td><?= $d['id'] ?></td>
                                        <td><?= htmlspecialchars($d['initiator_name']) ?></td>
                                        <td><?= htmlspecialchars($d['reference_code']) ?></td>
                                        <td><?= htmlspecialchars($d['reason']) ?></td>
                                        <td><span class="badge bg-warning text-dark"><?= htmlspecialchars($d['status']) ?></span></td>
                                        <td><?= htmlspecialchars($d['resolution_notes'] ?? 'Pending') ?></td>
                                        <td><?= date('M j, Y', strtotime($d['created_at'])) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Employees Tab -->
                    <div class="tab-pane fade" id="employees" role="tabpanel" tabindex="0">
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-glass align-middle">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Role</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Joined</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($all_employees as $emp): ?>
                                    <tr>
                                        <td><?= $emp['id'] ?></td>
                                        <td><span class="badge <?= $emp['role'] == 'admin' ? 'bg-danger' : 'bg-info text-dark' ?> text-uppercase"><?= htmlspecialchars($emp['role']) ?></span></td>
                                        <td><?= htmlspecialchars($emp['full_name']) ?></td>
                                        <td><?= htmlspecialchars($emp['email']) ?></td>
                                        <td><?= date('M j, Y', strtotime($emp['created_at'])) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
