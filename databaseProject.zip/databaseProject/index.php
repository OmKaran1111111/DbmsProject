<?php
require_once 'db_connect.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'customer') header('Location: customer_dashboard.php');
    elseif ($_SESSION['role'] === 'compliance') header('Location: compliance_dashboard.php');
    elseif ($_SESSION['role'] === 'admin') header('Location: admin_dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password.";
    } else {
        $stmt = $pdo->prepare("SELECT id, full_name, password_hash, role, tenant_id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['tenant_id'] = $user['tenant_id'];

            if ($user['role'] === 'customer') header('Location: customer_dashboard.php');
            elseif ($user['role'] === 'compliance') header('Location: compliance_dashboard.php');
            elseif ($user['role'] === 'admin') header('Location: admin_dashboard.php');
            exit;
        } else {
            $error = "Invalid credentials.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JiffyPay - Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center justify-content-center">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="glass-card mt-5 text-center">
                <h1 class="navbar-brand fs-1 mb-4">JiffyPay</h1>
                <p class="text-muted-custom mb-4">Welcome back! Please login to your account.</p>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger p-2"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3 text-start">
                        <label class="form-label text-muted-custom">Email Address</label>
                        <input type="email" name="email" class="form-control form-control-glass" placeholder="john@example.com" required value="john@example.com">
                    </div>
                    <div class="mb-4 text-start">
                        <label class="form-label text-muted-custom">Password</label>
                        <input type="password" name="password" class="form-control form-control-glass" placeholder="••••••••" required value="password123">
                        <small class="text-muted mt-1">Default test pass is 'password123'</small>
                    </div>
                    <button type="submit" class="btn btn-primary-custom w-100">Sign In</button>
                </form>
                
                <div class="mt-4 pt-3 border-top border-secondary">
                    <p class="small text-muted-custom">Don't have an account? <a href="register.php" class="text-gradient fw-bold text-decoration-none">Sign Up Here</a></p>
                    <p class="small text-muted-custom mt-3">Test Accounts:</p>
                    <ul class="list-unstyled small text-muted-custom">
                        <li>Customer: john@example.com (or om/sarim/waqar)</li>
                        <li>Compliance: compliance@jiffypay.com</li>
                        <li>Admin: admin@jiffypay.com</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>