<?php
require 'db_connect.php';

echo "Initial Balances:\n";
foreach ($pdo->query('SELECT id, balance FROM wallets WHERE id IN (3,4)') as $row) echo "W{$row['id']}: {$row['balance']}\n";

// 1. Transfer 100 from Wallet 3 to Wallet 4
echo "\nTransfering 100 from W3 to W4...\n";
$pdo->exec("UPDATE wallets SET balance = balance - 100 WHERE id = 3");
$pdo->exec("UPDATE wallets SET balance = balance + 100 WHERE id = 4");
$pdo->exec("INSERT INTO transactions (reference_code, sender_wallet_id, receiver_wallet_id, amount, transaction_type, status) VALUES ('TX-1', 3, 4, 100, 'transfer', 'completed')");
$tx_id = $pdo->lastInsertId();

echo "Balances after transfer:\n";
foreach ($pdo->query('SELECT id, balance FROM wallets WHERE id IN (3,4)') as $row) echo "W{$row['id']}: {$row['balance']}\n";

// 2. Open Dispute
echo "\nOpening Dispute...\n";
$pdo->exec("UPDATE wallets SET balance = balance - 100 WHERE id = 4"); // Escrow deduction
$pdo->exec("UPDATE transactions SET status = 'escrow' WHERE id = $tx_id");
$pdo->exec("INSERT INTO disputes (transaction_id, initiator_id, reason) VALUES ($tx_id, 3, 'Test')");
$dispute_id = $pdo->lastInsertId();

echo "Balances in escrow:\n";
foreach ($pdo->query('SELECT id, balance FROM wallets WHERE id IN (3,4)') as $row) echo "W{$row['id']}: {$row['balance']}\n";

// 3. Resolve Dispute (Refund)
echo "\nResolving Dispute (Refund)...\n";
$stmt = $pdo->prepare("CALL process_dispute_resolution(?, 'refund', 'resolved')");
$stmt->execute([$dispute_id]);

echo "Balances after refund:\n";
foreach ($pdo->query('SELECT id, balance FROM wallets WHERE id IN (3,4)') as $row) echo "W{$row['id']}: {$row['balance']}\n";
