<?php
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'compliance') {
    header('Location: index.php');
    exit;
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'resolve_dispute') {
        $dispute_id = intval($_POST['dispute_id']);
        $resolution = $_POST['resolution']; // 'refund' or 'reject'
        $notes = trim($_POST['notes']);
        
        if (in_array($resolution, ['refund', 'reject'])) {
            try {
                $stmt = $pdo->prepare("CALL process_dispute_resolution(?, ?, ?)");
                $stmt->execute([$dispute_id, $resolution, $notes]);
                
                $message = "Dispute resolved successfully.";
                $messageType = "success";
            } catch (PDOException $e) {
                $message = "Error resolving dispute: " . $e->getMessage();
                $messageType = "danger";
            }
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'resolve_fraud') {
        $log_id = intval($_POST['log_id']);
        $resolution = $_POST['resolution']; // 'approve', 'backtrack', or 'revert'
        
        if (in_array($resolution, ['approve', 'backtrack', 'revert'])) {
            try {
                $stmt = $pdo->prepare("CALL process_fraud_resolution(?, ?)");
                $stmt->execute([$log_id, $resolution]);
                
                $message = "Fraud hold resolved successfully.";
                $messageType = "success";
            } catch (PDOException $e) {
                $message = "Error resolving fraud hold: " . $e->getMessage();
                $messageType = "danger";
            }
        }
    }
}

// Fetch Active Disputes
$stmt = $pdo->query("SELECT * FROM view_active_disputes ORDER BY created_at ASC");
$disputes = $stmt->fetchAll();

// Fetch Fraud Logs
$stmt = $pdo->query("
    SELECT fl.*, fr.rule_name, t.amount, t.reference_code, t.status as tx_status, u.full_name as sender_name, u.email as sender_email
    FROM fraud_logs fl 
    JOIN fraud_rules fr ON fl.rule_id = fr.id
    LEFT JOIN transactions t ON fl.transaction_id = t.id
    LEFT JOIN users u ON fl.user_id = u.id
    ORDER BY fl.logged_at DESC LIMIT 50
");
$fraud_logs = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compliance Dashboard - JiffyPay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-glass py-3 mb-4">
  <div class="container">
    <a class="navbar-brand fs-4" href="#">JiffyPay <span class="fs-6 text-white fw-normal">| Compliance</span></a>
    <div class="d-flex align-items-center">
        <span class="text-main me-3">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></span>
        <a href="logout.php" class="btn btn-outline-custom btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> glass-card mb-4 border-0"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Active Disputes -->
        <div class="col-md-7">
            <div class="glass-card h-100">
                <h5 class="mb-4">Active Disputes (Escrow)</h5>
                
                <?php if(empty($disputes)): ?>
                    <p class="text-muted-custom">No active disputes at this time.</p>
                <?php else: ?>
                    <div class="accordion" id="disputesAccordion" data-bs-theme="dark">
                        <?php foreach($disputes as $index => $dispute): ?>
                            <div class="accordion-item bg-transparent border-secondary">
                                <h2 class="accordion-header">
                                    <button class="accordion-button <?= $index !== 0 ? 'collapsed' : '' ?> bg-transparent text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $dispute['dispute_id'] ?>">
                                        Dispute #<?= $dispute['dispute_id'] ?> | Ref: <?= htmlspecialchars($dispute['reference_code']) ?> | Amt: $<?= number_format($dispute['amount'], 2) ?>
                                    </button>
                                </h2>
                                <div id="collapse<?= $dispute['dispute_id'] ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" data-bs-parent="#disputesAccordion">
                                    <div class="accordion-body text-muted-custom">
                                        <p><strong>Initiator:</strong> <?= htmlspecialchars($dispute['initiator_name']) ?></p>
                                        <p><strong>Reason:</strong> <?= nl2br(htmlspecialchars($dispute['reason'])) ?></p>
                                        <p><strong>Date:</strong> <?= date('M j, Y H:i', strtotime($dispute['created_at'])) ?></p>
                                        
                                        <form method="POST" class="mt-3 bg-dark p-3 rounded border border-secondary">
                                            <input type="hidden" name="action" value="resolve_dispute">
                                            <input type="hidden" name="dispute_id" value="<?= $dispute['dispute_id'] ?>">
                                            <div class="mb-3">
                                                <label class="form-label text-white">Resolution Notes</label>
                                                <textarea name="notes" class="form-control form-control-glass" rows="2" required></textarea>
                                            </div>
                                            <div class="d-flex gap-2">
                                                <button type="submit" name="resolution" value="refund" class="btn btn-success btn-sm w-50">Approve Refund (Return to Sender)</button>
                                                <button type="submit" name="resolution" value="reject" class="btn btn-danger btn-sm w-50">Reject Dispute (Release to Receiver)</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Fraud Logs -->
        <div class="col-md-5">
            <div class="glass-card h-100">
                <h5 class="mb-4 text-warning">Automated Fraud Alerts</h5>
                <div class="overflow-auto" style="max-height: 500px;">
                    <?php if(empty($fraud_logs)): ?>
                        <p class="text-muted-custom">No fraud alerts logged.</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush" data-bs-theme="dark">
                            <?php foreach($fraud_logs as $log): ?>
                                <li class="list-group-item bg-transparent border-secondary px-0">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span class="badge bg-danger">Rule: <?= htmlspecialchars($log['rule_name']) ?></span>
                                        <small class="text-muted"><?= date('M j, H:i', strtotime($log['logged_at'])) ?></small>
                                    </div>
                                    <p class="mb-1 text-white small"><?= htmlspecialchars($log['description']) ?></p>
                                    <div class="small text-muted-custom">
                                        <?php if($log['reference_code']): ?>
                                            <div class="mb-1">Tx Ref: <?= htmlspecialchars($log['reference_code']) ?> ($<?= number_format($log['amount'], 2) ?>)</div>
                                            <div class="mb-1">Sender: <?= htmlspecialchars($log['sender_name']) ?> (<a href="mailto:<?= htmlspecialchars($log['sender_email']) ?>" class="text-info"><?= htmlspecialchars($log['sender_email']) ?></a>)</div>
                                            <div class="mb-2">Status: <span class="badge <?= $log['tx_status'] === 'pending' ? 'bg-warning text-dark' : ($log['tx_status'] === 'completed' ? 'bg-success' : 'bg-secondary') ?>"><?= htmlspecialchars(ucfirst($log['tx_status'])) ?></span></div>
                                            
                                            <?php if($log['tx_status'] === 'pending'): ?>
                                            <form method="POST" class="mt-2 p-2 bg-dark rounded border border-secondary">
                                                <input type="hidden" name="action" value="resolve_fraud">
                                                <input type="hidden" name="log_id" value="<?= $log['id'] ?>">
                                                <div class="d-flex gap-2">
                                                    <button type="submit" name="resolution" value="approve" class="btn btn-success btn-sm w-50">Approve & Release</button>
                                                    <button type="submit" name="resolution" value="backtrack" class="btn btn-danger btn-sm w-50">Backtrack to Sender</button>
                                                </div>
                                            </form>
                                            <?php elseif($log['tx_status'] === 'completed' && $log['status'] === 'cleared'): ?>
                                            <form method="POST" class="mt-2 p-2 bg-dark rounded border border-secondary">
                                                <input type="hidden" name="action" value="resolve_fraud">
                                                <input type="hidden" name="log_id" value="<?= $log['id'] ?>">
                                                <button type="submit" name="resolution" value="revert" class="btn btn-outline-danger btn-sm w-100" onclick="return confirm('Are you sure you want to forcibly reverse this completed transaction and claw back the funds?');">⚠ Revert Approved Transaction</button>
                                            </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            Tx Ref: N/A
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
