<?php
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';
$messageType = '';

// Fetch Wallet
$stmt = $pdo->prepare("SELECT id, wallet_number, balance, currency FROM wallets WHERE user_id = ?");
$stmt->execute([$user_id]);
$wallet = $stmt->fetch();

if (!$wallet) {
    die("No wallet found for your account.");
}

$wallet_id = $wallet['id'];

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        // 1. P2P Transfer (ACID Transaction)
        if ($action === 'transfer') {
            $recipient_number = trim($_POST['recipient_number'] ?? '');
            
            // Check if amount is properly provided and numeric
            if (!isset($_POST['amount']) || !is_numeric($_POST['amount'])) {
                $message = "Invalid input: Amount must be a valid number.";
                $messageType = "danger";
            } else {
                $amount = floatval($_POST['amount']);

                if (empty($recipient_number)) {
                    $message = "Invalid input: Recipient wallet number cannot be empty.";
                    $messageType = "danger";
                } elseif (!preg_match('/^W-\d+$/', $recipient_number)) {
                    $message = "Invalid input: Recipient wallet format is invalid (e.g. W-1000000001).";
                    $messageType = "danger";
                } elseif ($amount <= 0) {
                    $message = "Invalid transaction: You must transfer an amount greater than $0.00.";
                    $messageType = "danger";
                } elseif ($amount > 100000) {
                    $message = "Invalid transaction: Maximum allowed transfer is $100,000.";
                    $messageType = "danger";
                } elseif ($recipient_number === $wallet['wallet_number']) {
                    $message = "Invalid transaction: You cannot transfer money to your own wallet.";
                    $messageType = "danger";
                } elseif ($amount > $wallet['balance']) {
                    $message = "Invalid transaction: Insufficient balance. You are trying to send $" . number_format($amount, 2) . " but only have $" . number_format($wallet['balance'], 2) . ".";
                    $messageType = "danger";
                } else {
                    try {
                        $stmt = $pdo->prepare("CALL process_p2p_transfer(?, ?, ?, @ref, @status, @msg)");
                        $stmt->execute([$wallet_id, $recipient_number, $amount]);
                        
                        $res = $pdo->query("SELECT @ref AS ref, @status AS status, @msg AS msg")->fetch();
                        
                        // Refresh balance
                        $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE id = ?");
                        $stmt->execute([$wallet_id]);
                        $wallet['balance'] = $stmt->fetchColumn();

                        if ($res['status'] === 'pending') {
                            $message = "Transfer placed on hold: " . htmlspecialchars($res['msg']) . " Ref: " . htmlspecialchars($res['ref']);
                            $messageType = "warning";
                        } else {
                            $message = "Transfer successful! Ref: " . htmlspecialchars($res['ref']);
                            $messageType = "success";
                        }
                    } catch (PDOException $e) {
                        $error_msg = $e->getMessage();
                        if (strpos($error_msg, 'SQLSTATE[45000]') !== false) {
                            preg_match("/1644 (.*)/", $error_msg, $matches);
                            $clean_msg = isset($matches[1]) ? $matches[1] : "Validation failed.";
                            $message = "Transaction failed: " . htmlspecialchars($clean_msg);
                        } else {
                            $message = "Transaction failed: System error.";
                        }
                        $messageType = "danger";
                    }
                }
            }
        }
        
        // 2. Top-Up Wallet (Add Funds)
        elseif ($action === 'top_up') {
            if (!isset($_POST['amount']) || !is_numeric($_POST['amount'])) {
                $message = "Invalid input: Amount must be a valid number.";
                $messageType = "danger";
            } else {
                $amount = floatval($_POST['amount']);
                $payment_method = $_POST['payment_method'] ?? 'card';
                
                if ($amount <= 0) {
                    $message = "Invalid top-up: Amount must be greater than zero.";
                    $messageType = "danger";
                } elseif ($amount > 10000) {
                    $message = "Limit exceeded: You can only add a maximum of $10,000 at a time.";
                    $messageType = "danger";
                } else {
                    $result = run_transaction($pdo, function($pdo) use ($wallet_id, $amount, $payment_method) {
                        $reference = 'DEP-' . strtoupper(uniqid());

                        // Add to wallet
                        $stmt = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE id = ?");
                        $stmt->execute([$amount, $wallet_id]);

                        // Record Transaction
                        $stmt = $pdo->prepare("INSERT INTO transactions (reference_code, sender_wallet_id, receiver_wallet_id, amount, transaction_type, status, notes) VALUES (?, NULL, ?, ?, 'top_up', 'completed', ?)");
                        $stmt->execute([$reference, $wallet_id, $amount, "Top-up via " . $payment_method]);
                        
                        return $reference;
                    });

                    if ($result['success']) {
                        $message = "Successfully added $" . number_format($amount, 2) . " to your wallet. Ref: " . htmlspecialchars($result['data']);
                        $messageType = "success";
                        // Refresh balance
                        $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE id = ?");
                        $stmt->execute([$wallet_id]);
                        $wallet['balance'] = $stmt->fetchColumn();
                    } else {
                        $message = "Failed to add funds: " . htmlspecialchars($result['message']);
                        $messageType = "danger";
                    }
                }
            }
        }
        
        // 3. Generate Burner Card (Stored Procedure)
        elseif ($action === 'generate_card') {
            try {
                // Call stored procedure
                $stmt = $pdo->prepare("CALL generate_burner_card(?, @new_card)");
                $stmt->execute([$wallet_id]);
                
                $stmt2 = $pdo->query("SELECT @new_card AS card_number");
                $new_card = $stmt2->fetchColumn();
                
                $message = "New burner card generated successfully ending in " . substr($new_card, -4);
                $messageType = "success";
            } catch (PDOException $e) {
                $message = "Failed to generate card: " . $e->getMessage();
                $messageType = "danger";
            }
        }

        // 3. Dispute Transaction (Move to Escrow)
        elseif ($action === 'dispute') {
            $transaction_id = intval($_POST['transaction_id']);
            $reason = trim($_POST['reason']);
            
            if (empty($reason)) {
                $message = "Please provide a reason.";
                $messageType = "danger";
            } else {
                $result = run_transaction($pdo, function($pdo) use ($transaction_id, $wallet_id, $user_id, $reason) {
                    // Check if transaction exists and belongs to user
                    $stmt = $pdo->prepare("SELECT id, amount, sender_wallet_id, receiver_wallet_id, status FROM transactions WHERE id = ? AND sender_wallet_id = ? FOR UPDATE");
                    $stmt->execute([$transaction_id, $wallet_id]);
                    $trx = $stmt->fetch();
                    
                    if (!$trx) throw new Exception("Invalid transaction.");
                    if ($trx['status'] !== 'completed') throw new Exception("Only completed transactions can be disputed.");
                    
                    // Deduct from receiver (Escrow simulation)
                    $stmt = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE id = ?");
                    $stmt->execute([$trx['amount'], $trx['receiver_wallet_id']]);
                    
                    // Update Transaction Status to 'escrow'
                    $stmt = $pdo->prepare("UPDATE transactions SET status = 'escrow' WHERE id = ?");
                    $stmt->execute([$transaction_id]);
                    
                    // Create Dispute Ticket
                    $stmt = $pdo->prepare("INSERT INTO disputes (transaction_id, initiator_id, reason) VALUES (?, ?, ?)");
                    $stmt->execute([$transaction_id, $user_id, $reason]);
                    
                    return true;
                });
                
                if ($result['success']) {
                    $message = "Dispute filed. Funds are held in escrow pending compliance review.";
                    $messageType = "success";
                } else {
                    $message = "Failed to open dispute: " . $result['message'];
                    $messageType = "danger";
                }
            }
        }
    }
}

// Fetch Statements using the View
$stmt = $pdo->prepare("SELECT * FROM view_user_statements WHERE wallet_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$wallet_id]);
$statements = $stmt->fetchAll();

// Fetch Virtual Cards
$stmt = $pdo->prepare("SELECT * FROM virtual_cards WHERE wallet_id = ? AND status = 'active'");
$stmt->execute([$wallet_id]);
$cards = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - JiffyPay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-glass py-3 mb-4">
  <div class="container">
    <a class="navbar-brand fs-4" href="#">JiffyPay</a>
    <div class="d-flex align-items-center">
        <span class="text-main me-3">Welcome, <?= htmlspecialchars($_SESSION['full_name']) ?></span>
        <a href="logout.php" class="btn btn-outline-custom btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container">
    <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?> glass-card mb-4 border-0"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Balance Card -->
        <div class="col-md-4">
            <div class="glass-card h-100 position-relative">
                <h5 class="text-muted-custom">Available Balance</h5>
                <h1 class="display-4 fw-bold text-gradient mb-3">
                    <?= htmlspecialchars($wallet['currency']) ?> <?= number_format($wallet['balance'], 2) ?>
                </h1>
                <p class="mb-3 text-muted-custom small">Wallet Number: <span class="text-white fw-bold"><?= htmlspecialchars($wallet['wallet_number']) ?></span></p>
                <button class="btn btn-outline-success btn-sm w-100" data-bs-toggle="modal" data-bs-target="#topupModal">+ Add Funds</button>
            </div>
        </div>

        <!-- Transfer Funds -->
        <div class="col-md-4">
            <div class="glass-card h-100">
                <h5 class="mb-3">Send Money</h5>
                <form method="POST">
                    <input type="hidden" name="action" value="transfer">
                    <div class="mb-3">
                        <input type="text" name="recipient_number" class="form-control form-control-glass" placeholder="Recipient Wallet Number" required>
                    </div>
                    <div class="mb-3">
                        <input type="number" step="0.01" name="amount" class="form-control form-control-glass" placeholder="Amount" required>
                    </div>
                    <button type="submit" class="btn btn-primary-custom w-100">Transfer Now</button>
                </form>
            </div>
        </div>

        <!-- Virtual Cards -->
        <div class="col-md-4">
            <div class="glass-card h-100 d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">Virtual Cards</h5>
                    <form method="POST" class="m-0">
                        <input type="hidden" name="action" value="generate_card">
                        <button type="submit" class="btn btn-sm btn-outline-custom">+ New Burner</button>
                    </form>
                </div>
                
                <div class="overflow-auto" style="max-height: 200px;">
                    <?php if (count($cards) > 0): ?>
                        <?php foreach($cards as $card): ?>
                            <div class="virtual-card-ui mb-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <span class="badge bg-secondary"><?= ucfirst($card['card_type']) ?></span>
                                    <span class="text-muted small">VISA</span>
                                </div>
                                <div class="card-number mb-2 text-white">
                                    <?= chunk_split($card['card_number'], 4, ' ') ?>
                                </div>
                                <div class="d-flex justify-content-between text-muted small">
                                    <span>Exp: <?= htmlspecialchars($card['expiry_date']) ?></span>
                                    <span>CVV: <?= htmlspecialchars($card['cvv']) ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted-custom small">No active virtual cards.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Statements -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="glass-card">
                <h5 class="mb-4">Recent Transactions & Statements</h5>
                <div class="table-responsive">
                    <table class="table table-glass align-middle">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Ref Code</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th class="text-end">Amount</th>
                                <th class="text-end">Running Balance</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($statements as $stmt_row): ?>
                                <tr>
                                    <td><?= date('M j, Y H:i', strtotime($stmt_row['created_at'])) ?></td>
                                    <td><?= htmlspecialchars($stmt_row['reference_code']) ?></td>
                                    <td><span class="badge bg-dark border text-capitalize"><?= htmlspecialchars($stmt_row['transaction_type']) ?></span></td>
                                    <td>
                                        <?php if($stmt_row['status'] == 'completed'): ?>
                                            <span class="badge bg-success">Completed</span>
                                        <?php elseif($stmt_row['status'] == 'escrow'): ?>
                                            <span class="badge bg-warning">In Escrow</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?= htmlspecialchars($stmt_row['status']) ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end fw-bold <?= $stmt_row['amount_change'] < 0 ? 'text-danger' : 'text-success' ?>">
                                        <?= $stmt_row['amount_change'] < 0 ? '' : '+' ?><?= number_format($stmt_row['amount_change'], 2) ?>
                                    </td>
                                    <td class="text-end fw-bold"><?= number_format($stmt_row['running_balance'], 2) ?></td>
                                    <td>
                                        <?php if ($stmt_row['amount_change'] < 0 && $stmt_row['status'] == 'completed'): ?>
                                            <button class="btn btn-sm btn-outline-danger" onclick="openDisputeModal(<?= $stmt_row['transaction_id'] ?>, '<?= htmlspecialchars($stmt_row['reference_code']) ?>')">Dispute</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if(empty($statements)): ?>
                                <tr><td colspan="7" class="text-center text-muted-custom">No transactions found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Dispute Modal (Single Instance) -->
<div class="modal fade" id="disputeModal" tabindex="-1" data-bs-theme="dark">
  <div class="modal-dialog">
    <div class="modal-content glass-card">
      <div class="modal-header border-bottom border-secondary">
        <h5 class="modal-title">Dispute Transaction</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
          <div class="modal-body">
            <input type="hidden" name="action" value="dispute">
            <input type="hidden" name="transaction_id" id="dispute_transaction_id" value="">
            <p class="text-muted-custom">Ref: <span id="dispute_ref_code"></span></p>
            <div class="mb-3">
                <label class="form-label">Reason for dispute</label>
                <textarea name="reason" class="form-control form-control-glass" rows="3" required></textarea>
            </div>
            <p class="small text-warning">Funds will be moved to Escrow until Compliance reviews.</p>
          </div>
          <div class="modal-footer border-top border-secondary">
            <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger">Open Dispute</button>
          </div>
      </form>
    </div>
  </div>
</div>

<!-- Top-Up Modal -->
<div class="modal fade" id="topupModal" tabindex="-1" data-bs-theme="dark">
  <div class="modal-dialog">
    <div class="modal-content glass-card">
      <div class="modal-header border-bottom border-secondary">
        <h5 class="modal-title">Add Funds to Wallet</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST">
          <div class="modal-body">
            <input type="hidden" name="action" value="top_up">
            <div class="mb-3">
                <label class="form-label">Funding Source</label>
                <select name="payment_method" class="form-select form-control-glass" required>
                    <option value="Debit Card ending in 4242">Debit Card (••• 4242)</option>
                    <option value="Bank Account ending in 0091">Bank Account (••• 0091)</option>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Deposit Amount (<?= htmlspecialchars($wallet['currency']) ?>)</label>
                <input type="number" step="0.01" name="amount" class="form-control form-control-glass" placeholder="Amount (Max $10,000)" required>
            </div>
          </div>
          <div class="modal-footer border-top border-secondary">
            <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-success">Confirm Deposit</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function openDisputeModal(txId, refCode) {
    document.getElementById('dispute_transaction_id').value = txId;
    document.getElementById('dispute_ref_code').innerText = refCode;
    var modal = new bootstrap.Modal(document.getElementById('disputeModal'));
    modal.show();
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
