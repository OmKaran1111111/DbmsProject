<?php
require_once 'db_connect.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'customer') header('Location: customer_dashboard.php');
    elseif ($_SESSION['role'] === 'compliance') header('Location: compliance_dashboard.php');
    elseif ($_SESSION['role'] === 'admin') header('Location: admin_dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($full_name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email is already registered.";
        } else {
            // Register User
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // Assume tenant 1 is default for self-signup
            $tenant_id = 1;
            
            $result = run_transaction($pdo, function($pdo) use ($tenant_id, $full_name, $email, $hashed_password) {
                // Insert User
                $stmt = $pdo->prepare("INSERT INTO users (tenant_id, full_name, email, password_hash, role) VALUES (?, ?, ?, ?, 'customer')");
                $stmt->execute([$tenant_id, $full_name, $email, $hashed_password]);
                $user_id = $pdo->lastInsertId();
                
                // Generate a random wallet number W-100XXXXXXX
                $wallet_number = 'W-' . (1000000000 + $user_id);
                
                // Create a Wallet for the User (Starting with 0 balance or promotional 500 balance)
                $promo_balance = 500.00; // Giving $500 for testing
                $stmt = $pdo->prepare("INSERT INTO wallets (user_id, wallet_number, balance) VALUES (?, ?, ?)");
                $stmt->execute([$user_id, $wallet_number, $promo_balance]);
                
                return true;
            });
            
            if ($result['success']) {
                $success = "Registration successful! You can now login. You've received a $500 welcome bonus!";
            } else {
                $error = "Registration failed: " . $result['message'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JiffyPay - Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center justify-content-center">

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="glass-card mt-5 text-center">
                <h1 class="navbar-brand fs-1 mb-4">JiffyPay</h1>
                <p class="text-muted-custom mb-4">Create your new digital wallet account.</p>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger p-2"><?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success p-2">
                        <?= htmlspecialchars($success) ?><br>
                        <a href="index.php" class="btn btn-sm btn-success mt-2">Go to Login</a>
                    </div>
                <?php endif; ?>

                <?php if (!$success): ?>
                    <form method="POST" action="">
                        <div class="mb-3 text-start">
                            <label class="form-label text-muted-custom">Full Name</label>
                            <input type="text" name="full_name" class="form-control form-control-glass" placeholder="Jane Doe" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label text-muted-custom">Email Address</label>
                            <input type="email" name="email" class="form-control form-control-glass" placeholder="jane@example.com" required>
                        </div>
                        <div class="mb-4 text-start">
                            <label class="form-label text-muted-custom">Password</label>
                            <input type="password" name="password" class="form-control form-control-glass" placeholder="••••••••" required>
                        </div>
                        <button type="submit" class="btn btn-primary-custom w-100">Sign Up</button>
                    </form>
                <?php endif; ?>
                
                <div class="mt-4 pt-3 border-top border-secondary">
                    <p class="small text-muted-custom">Already have an account? <a href="index.php" class="text-gradient fw-bold text-decoration-none">Login here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
