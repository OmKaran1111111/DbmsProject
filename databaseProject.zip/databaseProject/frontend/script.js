const apiBase = 'http://localhost/databaseProject/backend';

const state = {
    dashboard: null
};

const currencyFormatter = new Intl.NumberFormat('en-PK', {
    style: 'currency',
    currency: 'PKR',
    maximumFractionDigits: 0
});

const dateFormatter = new Intl.DateTimeFormat('en-PK', {
    dateStyle: 'medium',
    timeStyle: 'short'
});

const elements = {
    statusBanner: document.getElementById('statusBanner'),
    metricsGrid: document.getElementById('metricsGrid'),
    transactionTableBody: document.getElementById('transactionTableBody'),
    customerTableBody: document.getElementById('customerTableBody'),
    cardTableBody: document.getElementById('cardTableBody'),
    alertTableBody: document.getElementById('alertTableBody'),
    disputeTableBody: document.getElementById('disputeTableBody'),
    customerForm: document.getElementById('customerForm'),
    transferForm: document.getElementById('transferForm'),
    cardForm: document.getElementById('cardForm'),
    disputeForm: document.getElementById('disputeForm'),
    resolveForm: document.getElementById('resolveForm'),
    senderWalletSelect: document.getElementById('senderWalletSelect'),
    receiverWalletSelect: document.getElementById('receiverWalletSelect'),
    cardCustomerSelect: document.getElementById('cardCustomerSelect'),
    disputeTransactionSelect: document.getElementById('disputeTransactionSelect'),
    disputeCustomerSelect: document.getElementById('disputeCustomerSelect'),
    resolveDisputeSelect: document.getElementById('resolveDisputeSelect'),
    officerSelect: document.getElementById('officerSelect'),
    navTabs: Array.from(document.querySelectorAll('[data-view-target]')),
    views: Array.from(document.querySelectorAll('.view'))
};

function setStatus(message, tone = 'info') {
    elements.statusBanner.textContent = message;
    elements.statusBanner.className = `status-banner ${tone}`;
}

function formatCurrency(value) {
    return currencyFormatter.format(Number(value || 0));
}

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

async function fetchJson(url, options = {}) {
    let response;

    try {
        response = await fetch(url, {
            ...options,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    } catch {
        throw new Error('Server not reachable.');
    }

    const text = await response.text();
    let data = {};

    try {
        data = text ? JSON.parse(text) : {};
    } catch {
        throw new Error('Invalid JSON from server.');
    }

    if (!response.ok) {
        throw new Error(data.message || 'Request failed.');
    }

    return data;
}

function renderMetrics(metrics) {
    const cards = [
        { label: 'Customers', value: metrics.customerCount },
        { label: 'Balance', value: formatCurrency(metrics.walletFloat) },
        { label: 'Transfers', value: formatCurrency(metrics.totalVolume) },
        { label: 'Cards', value: metrics.activeCards },
        { label: 'Alerts', value: metrics.openAlerts },
        { label: 'Disputes', value: metrics.openDisputes }
    ];

    elements.metricsGrid.innerHTML = cards.map(c => `
        <div class="metric-card">
            <span>${c.label}</span>
            <strong>${c.value}</strong>
        </div>
    `).join('');
}

function renderCustomerTable(data) {
    elements.customerTableBody.innerHTML = data.map(c => `
        <tr>
            <td>${escapeHtml(c.full_name)}</td>
            <td>${escapeHtml(c.wallet_number)}</td>
            <td>${formatCurrency(c.balance)}</td>
        </tr>
    `).join('');
}

function renderTransactionTable(data) {
    elements.transactionTableBody.innerHTML = data.map(t => `
        <tr>
            <td>${t.reference_code}</td>
            <td>${t.transaction_type}</td>
            <td>${t.sender_id || '-'}</td>
            <td>${t.receiver_id || '-'}</td>
            <td>${formatCurrency(t.amount)}</td>
            <td>${t.status}</td>
        </tr>
    `).join('');
}

function renderCardTable(data) {
    elements.cardTableBody.innerHTML = data.map(c => `
        <tr>
            <td>${c.user_id}</td>
            <td>${c.card_label}</td>
            <td>${c.card_type}</td>
            <td>${c.masked_number}</td>
            <td>${formatCurrency(c.spending_limit)}</td>
            <td>${c.status}</td>
        </tr>
    `).join('');
}

function renderDisputeTable(data) {
    elements.disputeTableBody.innerHTML = data.map(d => `
        <tr>
            <td>#${d.id}</td>
            <td>${d.customer_id}</td>
            <td>${d.reason}</td>
            <td>${d.status}</td>
        </tr>
    `).join('');
}

function populateSelect(select, data, valueKey, labelKey) {
    select.innerHTML = data.map(item =>
        `<option value="${item[valueKey]}">${item[labelKey]}</option>`
    ).join('');
}

function renderDashboard() {
    const d = state.dashboard;

    renderMetrics(d.metrics);
    renderCustomerTable(d.customers);
    renderTransactionTable(d.transactions);
    renderCardTable(d.cards);
    renderDisputeTable(d.disputes);

    populateSelect(elements.senderWalletSelect, d.customers, 'id', 'full_name');
    populateSelect(elements.receiverWalletSelect, d.customers, 'id', 'full_name');
    populateSelect(elements.cardCustomerSelect, d.customers, 'id', 'full_name');
    populateSelect(elements.disputeCustomerSelect, d.customers, 'id', 'full_name');
}

async function loadDashboard() {
    try {
        setStatus('Loading...');
        const data = await fetchJson(`${apiBase}/bootstrap.php`);
        state.dashboard = data;
        renderDashboard();
        setStatus('Loaded', 'success');
    } catch (e) {
        setStatus(e.message, 'error');
    }
}

async function submitJson(url, payload, message, form) {
    try {
        await fetchJson(url, {
            method: 'POST',
            body: JSON.stringify(payload)
        });

        form.reset();
        setStatus(message, 'success');
        loadDashboard();
    } catch (e) {
        setStatus(e.message, 'error');
    }
}

function attachHandlers() {
    elements.customerForm.addEventListener('submit', e => {
        e.preventDefault();
        const f = new FormData(e.target);

        submitJson(`${apiBase}/customers.php`, {
            fullName: f.get('fullName'),
            email: f.get('email'),
            phone: f.get('phone'),
            openingBalance: f.get('openingBalance')
        }, 'Customer created', e.target);
    });

    elements.transferForm.addEventListener('submit', e => {
        e.preventDefault();
        const f = new FormData(e.target);

        submitJson(`${apiBase}/transfers.php`, {
            senderWalletId: f.get('senderWalletId'),
            receiverWalletId: f.get('receiverWalletId'),
            amount: f.get('amount')
        }, 'Transfer done', e.target);
    });

    elements.cardForm.addEventListener('submit', e => {
        e.preventDefault();
        const f = new FormData(e.target);

        submitJson(`${apiBase}/cards.php`, {
            userId: f.get('userId'),
            cardLabel: f.get('cardLabel'),
            cardType: f.get('cardType'),
            spendingLimit: f.get('spendingLimit')
        }, 'Card issued', e.target);
    });

    elements.disputeForm.addEventListener('submit', e => {
        e.preventDefault();
        const f = new FormData(e.target);

        submitJson(`${apiBase}/disputes.php`, {
            transactionId: f.get('transactionId'),
            customerUserId: f.get('customerUserId'),
            reason: f.get('reason')
        }, 'Dispute created', e.target);
    });
}

function attachNav() {
    elements.navTabs.forEach(btn => {
        btn.onclick = () => {
            elements.navTabs.forEach(b => b.classList.remove('is-active'));
            btn.classList.add('is-active');

            elements.views.forEach(v =>
                v.classList.toggle('view-active', v.id === `view-${btn.dataset.viewTarget}`)
            );
        };
    });
}

attachHandlers();
attachNav();
loadDashboard();